#!/usr/bin/env bash
# ex280-trainer :: shared library
# Sourced by every setup/validate script. No `set -e` here on purpose:
# validation must keep running through individual failed checks.

# ---------- colors ----------
if [[ -t 1 ]]; then
  RED=$'\e[31m'; GRN=$'\e[32m'; YEL=$'\e[33m'; BLU=$'\e[34m'; BLD=$'\e[1m'; RST=$'\e[0m'
else
  RED=""; GRN=""; YEL=""; BLU=""; BLD=""; RST=""
fi

# ---------- scorecard ----------
_PASS=0
_FAIL=0
_FAILED_CHECKS=()

pass() { _PASS=$((_PASS+1)); printf '  %s✔%s %s\n' "$GRN" "$RST" "$1"; }
fail() { _FAIL=$((_FAIL+1)); _FAILED_CHECKS+=("$1"); printf '  %sx%s %s\n' "$RED" "$RST" "$1"; }
info() { printf '  %s•%s %s\n' "$BLU" "$RST" "$1"; }
hdr()  { printf '\n%s%s%s\n' "$BLD" "$1" "$RST"; }

# check "<description>" <command...>  -> pass if command exits 0
check() {
  local desc="$1"; shift
  if "$@" >/dev/null 2>&1; then pass "$desc"; else fail "$desc"; fi
}

# check_eq "<description>" "<expected>" "<actual>"
check_eq() {
  local desc="$1" exp="$2" act="$3"
  if [[ "$exp" == "$act" ]]; then pass "$desc"
  else fail "$desc (erwartet: '$exp', ist: '$act')"; fi
}

# check_contains "<description>" "<needle>" "<haystack>"
check_contains() {
  local desc="$1" needle="$2" hay="$3"
  if [[ "$hay" == *"$needle"* ]]; then pass "$desc"
  else fail "$desc (nicht gefunden: '$needle')"; fi
}

# jsonpath helper: ocjp <jsonpath> <oc args...>
ocjp() { local jp="$1"; shift; oc get "$@" -o jsonpath="$jp" 2>/dev/null; }

# require an object to exist: obj_exists <kind> <name> [-n ns]
obj_exists() { oc get "$@" >/dev/null 2>&1; }

# ---------- summary ----------
summary() {
  local total=$((_PASS+_FAIL))
  hdr "Ergebnis: ${_PASS}/${total} Checks bestanden"
  if (( _FAIL > 0 )); then
    printf '%sOffene Punkte:%s\n' "$YEL" "$RST"
    local c; for c in "${_FAILED_CHECKS[@]}"; do printf '  - %s\n' "$c"; done
    return 1
  fi
  printf '%s%sAlle Checks bestanden — Task gelöst.%s\n' "$BLD" "$GRN" "$RST"
  return 0
}

# ---------- guards ----------
need_oc() {
  command -v oc >/dev/null 2>&1 || { echo "${RED}oc nicht im PATH${RST}"; exit 2; }
  oc whoami >/dev/null 2>&1 || { echo "${RED}Nicht an einem Cluster angemeldet (oc login).${RST}"; exit 2; }
}

# ensure a project exists (idempotent), switch into it
ensure_project() {
  local p="$1"
  oc get project "$p" >/dev/null 2>&1 || oc new-project "$p" >/dev/null 2>&1 || oc adm new-project "$p" >/dev/null 2>&1
  oc project "$p" >/dev/null 2>&1
}

# delete project quietly if it exists
drop_project() {
  oc get project "$1" >/dev/null 2>&1 && oc delete project "$1" --wait=false >/dev/null 2>&1
}
