#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 19 Validate — CronJob Creation"
check "CronJob 'job-runner' in scheduler existiert" obj_exists cronjob job-runner -n scheduler
check_eq "Schedule = '5 4 2 * *'" "5 4 2 * *" "$(ocjp '{.spec.schedule}' cronjob job-runner -n scheduler)"
check_eq "successfulJobsHistoryLimit = 14" "14" "$(ocjp '{.spec.successfulJobsHistoryLimit}' cronjob job-runner -n scheduler)"
check_eq "serviceAccountName = trigger-sa" "trigger-sa" "$(ocjp '{.spec.jobTemplate.spec.template.spec.serviceAccountName}' cronjob job-runner -n scheduler)"
IMG="$(ocjp '{.spec.jobTemplate.spec.template.spec.containers[0].image}' cronjob job-runner -n scheduler)"
check_contains "Image bitnami/nginx" "bitnami/nginx" "$IMG"
summary
