#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 10 Setup — Inject Secret into Application"
ensure_project moon
oc -n moon get secret moon-secret >/dev/null 2>&1 || \
  oc -n moon create secret generic moon-secret --from-literal=moon-key=moon-password >/dev/null 2>&1
oc -n moon get deploy satellite >/dev/null 2>&1 || \
  oc -n moon create deployment satellite --image=registry.access.redhat.com/ubi9/httpd-24 >/dev/null 2>&1
info "Deployment 'satellite' in 'moon'. Ziel: ENV 'MOON_KEY' aus Secret 'moon-secret' Key 'moon-key'."
