#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 3 Validate — Project Permissions / Roles"
check "alice ist admin in team-beta" bash -c "oc auth can-i '*' '*' --as=alice -n team-beta 2>/dev/null | grep -q yes"
# charlie view@finance-apps: darf get pods, nicht delete
check "charlie darf finance-apps sehen (get pods)" bash -c "oc auth can-i get pods --as=charlie -n finance-apps 2>/dev/null | grep -q yes"
if oc auth can-i delete pods --as=charlie -n finance-apps 2>/dev/null | grep -q no; then pass "charlie darf finance-apps NICHT verändern"; else fail "charlie darf finance-apps NICHT verändern (mehr als view?)"; fi
# david edit@it-automation: darf pods bearbeiten, aber keine rolebindings
check "david darf it-automation bearbeiten (create deploy)" bash -c "oc auth can-i create deployments --as=david -n it-automation 2>/dev/null | grep -q yes"
if oc auth can-i create rolebindings --as=david -n it-automation 2>/dev/null | grep -q no; then pass "david darf KEINE rolebindings (edit, nicht admin)"; else fail "david darf KEINE rolebindings — vermutlich admin statt edit vergeben"; fi
summary
