#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 6 Setup — Manually Scale Deployment"
ensure_project apollo
oc -n apollo get deploy jet >/dev/null 2>&1 || \
  oc -n apollo create deployment jet --image="$(httpd_image)" >/dev/null 2>&1
oc -n apollo scale deployment jet --replicas=1 >/dev/null 2>&1
info "Deployment 'jet' im Projekt 'apollo' steht auf 1 Replica. Ziel: genau 5."
