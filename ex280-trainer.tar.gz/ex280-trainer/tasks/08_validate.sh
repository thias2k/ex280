#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 8 Validate — LimitRange in bluebook"
check "LimitRange 'bluebook-limits' existiert" obj_exists limitrange bluebook-limits -n bluebook
J="$(oc get limitrange bluebook-limits -n bluebook -o json 2>/dev/null)"
get(){ echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
for l in d['spec']['limits']:
  if l.get('type')=='$1':
    print(l.get('$2',{}).get('$3',''))
    break" 2>/dev/null; }
check_eq "Container max memory = 250Mi"          "250Mi" "$(get Container max memory)"
check_eq "Container min memory = 50Mi"           "50Mi"  "$(get Container min memory)"
check_eq "Container defaultRequest memory=100Mi" "100Mi" "$(get Container defaultRequest memory)"
check_eq "Container defaultRequest cpu = 100m"   "100m"  "$(get Container defaultRequest cpu)"
check_eq "Pod max cpu = 250m"                    "250m"  "$(get Pod max cpu)"
check_eq "Pod min cpu = 50m"                     "50m"   "$(get Pod min cpu)"
summary
