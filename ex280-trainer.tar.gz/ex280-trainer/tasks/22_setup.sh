#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 22 Setup — NetworkPolicy frontend/backend"
ensure_project backend
ensure_project frontend
# frontend NS-Label und Pod-Label setzen, damit Selektoren matchbar sind
oc label ns frontend team=security --overwrite >/dev/null 2>&1
oc -n frontend get deploy sql >/dev/null 2>&1 || \
  oc -n frontend create deployment sql --image="$(httpd_image)" >/dev/null 2>&1
oc -n frontend patch deploy sql --type=merge -p '{"spec":{"template":{"metadata":{"labels":{"deployment":"sql"}}}}}' >/dev/null 2>&1
oc -n backend get deploy db >/dev/null 2>&1 || \
  oc -n backend create deployment db --image="$(httpd_image)" >/dev/null 2>&1
info "Projekte frontend (label team=security, pod deployment=sql) und backend bereit."
info "Ziel: NetworkPolicy 'db-allow-conn' in 'backend', erlaubt nur frontend-Pods (team=security/deployment=sql) auf TCP 3306."
