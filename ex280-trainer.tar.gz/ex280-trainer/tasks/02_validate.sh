#!/usr/bin/env bash
# Task 2 — Cluster Access Control / RBAC :: VALIDATE
source "$(dirname "$0")/../lib/common.sh"
need_oc
hdr "Task 2 Validate — RBAC Users"

# emma cluster-admin
check "emma kann als cluster-admin alles (can-i '*' '*')" \
  bash -c "oc auth can-i '*' '*' --as=emma 2>/dev/null | grep -q yes"

# alice darf Projekte anlegen (self-provisioner)
check "alice darf Projekte anlegen" \
  bash -c "oc auth can-i create projectrequests --as=alice 2>/dev/null | grep -q yes"

# david darf KEINE Projekte anlegen
if oc auth can-i create projectrequests --as=david 2>/dev/null | grep -q no; then
  pass "david darf KEINE Projekte anlegen"
else
  fail "david darf KEINE Projekte anlegen (self-provisioner noch aktiv?)"
fi

# charlie ist NICHT cluster-admin
if oc auth can-i '*' '*' --as=charlie 2>/dev/null | grep -q no; then
  pass "charlie ist NICHT cluster-admin"
else
  fail "charlie ist NICHT cluster-admin"
fi

# bob cluster-reader: darf nodes lesen, aber nicht schreiben
check "bob darf clusterweit lesen (get nodes)" \
  bash -c "oc auth can-i get nodes --as=bob 2>/dev/null | grep -q yes"
if oc auth can-i delete nodes --as=bob 2>/dev/null | grep -q no; then
  pass "bob darf NICHT verändern (delete nodes)"
else
  fail "bob darf NICHT verändern (delete nodes) — mehr als cluster-reader?"
fi

# kubeadmin secret entfernt
if oc get secret kubeadmin -n kube-system >/dev/null 2>&1; then
  fail "kubeadmin-Secret existiert noch (oc delete secret kubeadmin -n kube-system)"
else
  pass "kubeadmin-Secret ist entfernt"
fi

summary
