#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 11 Validate — ServiceAccount + anyuid SCC"
check "ServiceAccount 'redhat-sa' in production existiert" obj_exists sa redhat-sa -n production

# Seit OCP 4.5 schreibt add-scc-to-user NICHT mehr ins scc.users-Feld, sondern legt eine
# (Cluster)RoleBinding auf ClusterRole system:openshift:scc:anyuid an.
# Verlässlich ist daher die RBAC-Auswertung via 'oc auth can-i use scc/anyuid'.
SA="system:serviceaccount:production:redhat-sa"
if oc auth can-i use scc/anyuid --as="$SA" -n production 2>/dev/null | grep -q yes; then
  pass "redhat-sa darf SCC 'anyuid' nutzen (RBAC)"
else
  # Fallbacks: (a) altes scc.users-Feld (ältere Cluster), (b) RoleBinding direkt suchen
  SCC_USERS="$(oc get scc anyuid -o jsonpath='{.users[*]}' 2>/dev/null)"
  RB_HIT="$( { oc get rolebinding,clusterrolebinding -A -o json 2>/dev/null; } | python3 -c "import sys,json
try: d=json.load(sys.stdin)
except: print('no'); sys.exit()
for rb in d.get('items',[]):
    rr=rb.get('roleRef',{})
    if rr.get('name')=='system:openshift:scc:anyuid':
        for s in rb.get('subjects') or []:
            if s.get('kind')=='ServiceAccount' and s.get('name')=='redhat-sa' and s.get('namespace')=='production':
                print('yes'); sys.exit()
print('no')" 2>/dev/null)"
  if echo "$SCC_USERS" | grep -q "$SA" || [[ "$RB_HIT" == "yes" ]]; then
    pass "redhat-sa darf SCC 'anyuid' nutzen (Binding gefunden)"
  else
    fail "redhat-sa darf SCC 'anyuid' nutzen"
    info "  Pruefe: oc auth can-i use scc/anyuid --as=$SA -n production"
    info "  Tipp: 'oc adm policy add-scc-to-user anyuid -z redhat-sa' IM Projekt production ausfuehren (-n wird ignoriert)."
  fi
fi
summary
