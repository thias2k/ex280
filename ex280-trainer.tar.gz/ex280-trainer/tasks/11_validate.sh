#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 11 Validate — ServiceAccount + anyuid SCC"
check "ServiceAccount 'redhat-sa' in production existiert" obj_exists sa redhat-sa -n production
# Prüfe SCC-Zuordnung robust: über scc users ODER rolebinding auf system:openshift:scc:anyuid
SCC_USERS="$(oc get scc anyuid -o jsonpath='{.users[*]}' 2>/dev/null)"
if echo "$SCC_USERS" | grep -q 'system:serviceaccount:production:redhat-sa'; then
  pass "anyuid SCC an redhat-sa gebunden"
else
  RB="$(oc get rolebinding -n production -o json 2>/dev/null | grep -c 'anyuid')"
  if [[ "${RB:-0}" -gt 0 ]]; then pass "anyuid SCC an redhat-sa gebunden (via RoleBinding)"; else fail "anyuid SCC an redhat-sa gebunden"; fi
fi
summary
