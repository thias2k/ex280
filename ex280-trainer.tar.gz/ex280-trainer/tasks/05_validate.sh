#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 5 Validate — ResourceQuota in team-alpha"
check "ResourceQuota 'ex280-quota' in team-alpha existiert" obj_exists resourcequota ex280-quota -n team-alpha
check_eq "requests.cpu = 2"            "2"     "$(ocjp '{.spec.hard.requests\.cpu}' resourcequota ex280-quota -n team-alpha)"
check_eq "requests.memory = 400Mi"     "400Mi" "$(ocjp '{.spec.hard.requests\.memory}' resourcequota ex280-quota -n team-alpha)"
check_eq "pods = 3"                    "3"     "$(ocjp '{.spec.hard.pods}' resourcequota ex280-quota -n team-alpha)"
check_eq "services = 4"                "4"     "$(ocjp '{.spec.hard.services}' resourcequota ex280-quota -n team-alpha)"
check_eq "replicationcontrollers = 5"  "5"     "$(ocjp '{.spec.hard.replicationcontrollers}' resourcequota ex280-quota -n team-alpha)"
summary
