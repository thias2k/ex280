#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 14 Setup — ConfigMap from file + mount"
ensure_project publish
mkdir -p "$HOME/web"
[[ -f "$HOME/web/index.html" ]] || echo "<h1>EX280 message</h1>" > "$HOME/web/index.html"
oc -n publish get deploy web >/dev/null 2>&1 || \
  oc -n publish create deployment web --image=registry.access.redhat.com/ubi9/httpd-24 >/dev/null 2>&1
info "Datei ~/web/index.html und Deployment 'web' in 'publish' bereit."
info "Ziel: ConfigMap 'web-cm' aus der Datei, gemountet unter /messages im Deployment 'web'."
