#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 7 Validate — Horizontal Pod Autoscaler"
check_eq "Container request cpu = 50m"  "50m"  "$(ocjp '{.spec.template.spec.containers[0].resources.requests.cpu}' deploy titan -n solar)"
check_eq "Container limit cpu = 250m"   "250m" "$(ocjp '{.spec.template.spec.containers[0].resources.limits.cpu}' deploy titan -n solar)"
check "HPA für titan existiert" obj_exists hpa titan -n solar
check_eq "HPA minReplicas = 2" "2" "$(ocjp '{.spec.minReplicas}' hpa titan -n solar)"
check_eq "HPA maxReplicas = 5" "5" "$(ocjp '{.spec.maxReplicas}' hpa titan -n solar)"
# v2 oder v1 Feld abdecken
T2="$(ocjp '{.spec.metrics[0].resource.target.averageUtilization}' hpa titan -n solar)"
T1="$(ocjp '{.spec.targetCPUUtilizationPercentage}' hpa titan -n solar)"
check_eq "HPA Ziel-CPU = 75%" "75" "${T2:-$T1}"
summary
