#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 7 Validate — Horizontal Pod Autoscaler"
check_eq "Container request cpu = 50m"  "50m"  "$(ocjp '{.spec.template.spec.containers[0].resources.requests.cpu}' deploy titan -n solar)"
check_eq "Container limit cpu = 250m"   "250m" "$(ocjp '{.spec.template.spec.containers[0].resources.limits.cpu}' deploy titan -n solar)"
# HPA über scaleTargetRef finden (Aufgabe gibt KEINEN HPA-Namen vor -> Name ist frei).
HPA_NAME="$(oc get hpa -n solar -o json 2>/dev/null | python3 -c "import sys,json
try: d=json.load(sys.stdin)
except: sys.exit()
for h in d.get('items',[]):
    if h.get('spec',{}).get('scaleTargetRef',{}).get('name')=='titan':
        print(h['metadata']['name']); break" 2>/dev/null)"

if [[ -n "$HPA_NAME" ]]; then
  pass "HPA für Deployment titan existiert ($HPA_NAME)"
  check_eq "HPA minReplicas = 2" "2" "$(ocjp '{.spec.minReplicas}' hpa "$HPA_NAME" -n solar)"
  check_eq "HPA maxReplicas = 5" "5" "$(ocjp '{.spec.maxReplicas}' hpa "$HPA_NAME" -n solar)"
  # v2 (autoscaling/v2) oder v1 Feld abdecken
  T2="$(ocjp '{.spec.metrics[0].resource.target.averageUtilization}' hpa "$HPA_NAME" -n solar)"
  T1="$(ocjp '{.spec.targetCPUUtilizationPercentage}' hpa "$HPA_NAME" -n solar)"
  check_eq "HPA Ziel-CPU = 75%" "75" "${T2:-$T1}"
else
  fail "HPA für Deployment titan existiert (keine HPA mit scaleTargetRef=titan in solar gefunden)"
  fail "HPA minReplicas = 2 (keine passende HPA)"
  fail "HPA maxReplicas = 5 (keine passende HPA)"
  fail "HPA Ziel-CPU = 75% (keine passende HPA)"
fi
summary
