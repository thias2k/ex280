#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 5 Setup — ResourceQuota in team-alpha"
ensure_project team-alpha
info "Ziel: ResourceQuota 'ex280-quota' — requests.memory=400Mi, requests.cpu=2, pods=3, services=4, replicationcontrollers=5"
