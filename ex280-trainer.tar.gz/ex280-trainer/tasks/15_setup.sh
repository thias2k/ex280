#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 15 Setup — Secure Route (edge TLS)"
ensure_project business
oc -n business get deploy marketing >/dev/null 2>&1 || \
  oc -n business create deployment marketing --image="$(httpd_image)" >/dev/null 2>&1
oc -n business get svc marketing >/dev/null 2>&1 || \
  oc -n business expose deployment marketing --port=8080 >/dev/null 2>&1
oc -n business get route marketing-route >/dev/null 2>&1 || \
  oc -n business expose svc marketing --name=marketing-route >/dev/null 2>&1
info "Unsichere Route 'marketing-route' in 'business' bereit."
echo
info "Ziel: edge-terminierte HTTPS-Route fuer https://webapplication.apps.domain1.exampledomain.com"
info "Subject: /C=US/ST=NV/L=California/O=Hat/OU=IT/CN=webapplication.apps.domain1.exampledomain.com"
echo
printf '  %s!%s %scert-manager.sh existiert NUR im echten Red-Hat-Lab (lab start).%s In diesem Trainer\n' "$YEL" "$RST" "$BLD" "$RST"
info "  erzeugst du Cert+Key selbst mit openssl (in der Pruefung der robustere Weg)."
info "  Befehle (einzeilig, copy-paste-freundlich):"
echo
info "  openssl req -x509 -newkey rsa:2048 -nodes -keyout marketing.key -out marketing.crt -days 365 -subj \"/C=US/ST=NV/L=California/O=Hat/OU=IT/CN=webapplication.apps.domain1.exampledomain.com\""
info "  oc delete route marketing-route -n business"
info "  oc create route edge marketing-route --service=marketing --hostname=webapplication.apps.domain1.exampledomain.com --cert=marketing.crt --key=marketing.key -n business"
