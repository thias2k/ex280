#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 15 Setup — Secure Route (edge TLS)"
ensure_project business
oc -n business get deploy marketing >/dev/null 2>&1 || \
  oc -n business create deployment marketing --image=registry.access.redhat.com/ubi9/httpd-24 >/dev/null 2>&1
oc -n business get svc marketing >/dev/null 2>&1 || \
  oc -n business expose deployment marketing --port=8080 >/dev/null 2>&1
oc -n business get route marketing-route >/dev/null 2>&1 || \
  oc -n business expose svc marketing --name=marketing-route >/dev/null 2>&1
info "Unsichere Route 'marketing-route' in 'business' bereit."
info "Ziel: edge-terminierte HTTPS-Route, CN=webapplication.apps.domain1.exampledomain.com (cert-manager.sh)."
