#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 16 Setup — Install File Integrity Operator"
info "Ziel: File Integrity Operator in 'openshift-file-integrity', approval=Automatic,"
info "      cluster monitoring fürs Namespace aktiviert (Label openshift.io/cluster-monitoring=true)."
info "Keine Vorbereitung — Installation via OperatorHub/Subscription machst du selbst."
