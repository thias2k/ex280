#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 18 Setup — Collect & Upload Cluster Support Data"
info "Ziel: oc adm must-gather, als ex280-ocp-<clusterID>.tar.gz packen, mit upload-cluster-data hochladen."
info "ClusterID: oc get clusterversion -o jsonpath='{.items[0].spec.clusterID}'"
info "Dieser Task wird teil-validiert (Artefakt-Existenz im HOME)."
