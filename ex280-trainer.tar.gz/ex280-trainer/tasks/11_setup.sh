#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 11 Setup — ServiceAccount + anyuid SCC"
ensure_project production
info "Ziel: ServiceAccount 'redhat-sa' in 'production' mit SCC 'anyuid'."
info "oc create sa redhat-sa -n production ; oc adm policy add-scc-to-user anyuid -z redhat-sa -n production"
