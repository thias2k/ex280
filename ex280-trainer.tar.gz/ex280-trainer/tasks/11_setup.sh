#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 11 Setup — ServiceAccount + anyuid SCC"
ensure_project production
info "Ziel: ServiceAccount 'redhat-sa' in 'production' mit Recht auf SCC 'anyuid'."
info "   oc create sa redhat-sa -n production"
info "   oc project production   # WICHTIG: -n wird von add-scc-to-user ignoriert, daher ins Projekt wechseln"
info "   oc adm policy add-scc-to-user anyuid -z redhat-sa"
info "Hinweis: seit OCP 4.5 entsteht dabei eine RoleBinding auf ClusterRole system:openshift:scc:anyuid"
info "         (NICHT mehr ein Eintrag im scc.users-Feld). Pruefung via 'oc auth can-i use scc/anyuid'."
