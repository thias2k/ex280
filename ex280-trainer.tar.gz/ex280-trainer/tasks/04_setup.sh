#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 4 Setup — Groups and Group Permissions"
ensure_project team-alpha
info "Ziele: Gruppen 'manager'(alice) & 'project-admin'(charlie,david)."
info "       manager=edit@team-alpha, project-admin=view@team-alpha."
