#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 22 Validate — NetworkPolicy frontend/backend"
check "NetworkPolicy 'db-allow-conn' in backend existiert" obj_exists networkpolicy db-allow-conn -n backend
J="$(oc get networkpolicy db-allow-conn -n backend -o json 2>/dev/null)"
echo "$J" | grep -q '"Ingress"' && pass "policyType Ingress gesetzt" || fail "policyType Ingress gesetzt"
PORT="$(echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
ports=[]
for ing in d['spec'].get('ingress',[]):
  for p in ing.get('ports',[]): ports.append(str(p.get('port')))
print(','.join(ports))" 2>/dev/null)"
check_contains "Port 3306 erlaubt" "3306" "$PORT"
SEL="$(echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
import json as j
print(j.dumps(d['spec'].get('ingress',[])))" 2>/dev/null)"
check_contains "namespaceSelector team=security" "security" "$SEL"
check_contains "podSelector deployment=sql" "sql" "$SEL"
summary
