#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 17 Setup — Helm Repo + Install + Upgrade"
ensure_project bluebook
info "Ziel: helm repo 'nginx-repo' (https://kubernetesway.github.io/my-helm-repo),"
info "      Release 'example-app' v0.1.0 installieren, dann auf 0.2.0 upgraden."
command -v helm >/dev/null 2>&1 || info "Hinweis: 'helm' muss im PATH sein."
