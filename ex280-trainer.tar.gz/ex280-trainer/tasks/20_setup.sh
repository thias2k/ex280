#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 20 Setup — PV + PVC + Deployment + Route"
ensure_project webserver
info "Annahme: NFS-StorageClass existiert bereits im Lab (z.B. nfs-storage)."
info "Ziele: PV 'wev-pv' (ReadOnlyMany,1Gi,reclaim wie SC, path /exports-ocp4/page),"
info "       PVC 'web-pvc' (1Gi, ReadOnlyMany), Deployment 'web-landing' (3 Replicas,"
info "       hello-world-nginx, mount /usr/share/nginx/html), HTTPS-Route auf den vorgegebenen Host."
