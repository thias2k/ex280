#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 20 Setup — PV + PVC + Deployment + Route"
ensure_project webserver
info "Annahme: NFS-StorageClass existiert bereits im Lab (z.B. nfs-storage)."
info "Image (Classroom-Registry): registry.ocp4.example.com:8443/redhattraining/hello-world-nginx:v1.0"
info "Ziele: PV 'wev-pv' (ReadOnlyMany,1Gi,reclaim wie SC), PVC 'web-pvc' (1Gi, ReadOnlyMany),"
info "       Deployment 'web-landing' (3 Replicas), mount /usr/share/nginx/html, HTTPS-Route."
echo
printf '  %s!%s %sNFS server-IP und path NIEMALS raten%s — aus der Umgebung ermitteln:\n' "$YEL" "$RST" "$BLD" "$RST"
info "  Server-IP+Pfad aus vorhandenem PV:  oc get pv -o jsonpath='{range .items[*]}{.spec.nfs.server}{\"  \"}{.spec.nfs.path}{\"\\n\"}{end}'"
info "  Exportierte Pfade vom Server:        showmount -e <server-ip>"
info "  (Vorlagenpfad /exports-ocp4/page existiert evtl. nicht; haeufig ist nur /exports-ocp4 exportiert.)"
echo
printf '  %s!%s %soc image info meldet bei Classroom-Images oft "unauthorized"%s — irrefuehrend:\n' "$YEL" "$RST" "$BLD" "$RST"
info "  Client hat kein Registry-Login, aber die NODES ziehen das Image (eigenes Pull-Secret)."
info "  Verlass dich auf 'oc get pods' / 'oc describe pod', nicht auf oc image info."
echo
info "PVC braucht YAML (ReadOnlyMany ist in der Web-Console nicht waehlbar)."
info "PV und PVC: gleicher storageClassName (nfs-storage), Groesse (1Gi), kompatibler AccessMode -> sonst kein Bound."
