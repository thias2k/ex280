#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 17 Validate — Helm Repo + Install + Upgrade"
command -v helm >/dev/null 2>&1 || { fail "helm nicht im PATH"; summary; exit 1; }
# Release example-app in irgendeinem erreichbaren Namespace; default bluebook
NS="${EX280_HELM_NS:-bluebook}"
HJSON="$(helm list -n "$NS" -o json 2>/dev/null)"
if echo "$HJSON" | grep -q '"name":"example-app"'; then pass "Helm-Release 'example-app' existiert"; else fail "Helm-Release 'example-app' existiert (Namespace $NS?)"; fi
CHART="$(echo "$HJSON" | python3 -c "import sys,json
try:
 d=json.load(sys.stdin)
 for r in d:
  if r['name']=='example-app': print(r.get('chart',''))
except: pass" 2>/dev/null)"
check_contains "Chart-Version 0.2.0 (Upgrade erfolgt)" "0.2.0" "$CHART"
summary
