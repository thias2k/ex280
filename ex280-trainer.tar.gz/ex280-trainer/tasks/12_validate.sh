#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 12 Validate — Deployment using ServiceAccount"
check_eq "Deployment 'team' nutzt SA 'redhat-sa'" "redhat-sa" "$(ocjp '{.spec.template.spec.serviceAccountName}' deploy team -n production)"
AVAIL="$(ocjp '{.status.availableReplicas}' deploy team -n production)"; AVAIL="${AVAIL:-0}"
if [[ "$AVAIL" -ge 1 ]]; then pass "Mindestens 1 Pod verfügbar (Output möglich)"; else fail "Kein verfügbarer Pod (läuft die App?)"; fi
summary
