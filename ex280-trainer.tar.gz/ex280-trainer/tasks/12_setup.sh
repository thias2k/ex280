#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 12 Setup — Deployment using ServiceAccount"
ensure_project production
oc -n production get sa redhat-sa >/dev/null 2>&1 || oc -n production create sa redhat-sa >/dev/null 2>&1
oc -n production get deploy team >/dev/null 2>&1 || \
  oc -n production create deployment team --image="$(httpd_image)" >/dev/null 2>&1
info "Deployment 'team' in 'production'. Ziel: läuft unter ServiceAccount 'redhat-sa' und liefert Output."
