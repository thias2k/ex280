#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 20 Validate — PV + PVC + Deployment + Route"
# PV
check "PV 'wev-pv' existiert" obj_exists pv wev-pv
check_eq "PV AccessMode ReadOnlyMany" "ReadOnlyMany" "$(ocjp '{.spec.accessModes[0]}' pv wev-pv)"
check_eq "PV Size 1Gi" "1Gi" "$(ocjp '{.spec.capacity.storage}' pv wev-pv)"
check_eq "PV NFS path /exports-ocp4/page" "/exports-ocp4/page" "$(ocjp '{.spec.nfs.path}' pv wev-pv)"
# PVC
check "PVC 'web-pvc' in webserver existiert" obj_exists pvc web-pvc -n webserver
check_eq "PVC AccessMode ReadOnlyMany" "ReadOnlyMany" "$(ocjp '{.spec.accessModes[0]}' pvc web-pvc -n webserver)"
check_eq "PVC gebunden (Bound)" "Bound" "$(ocjp '{.status.phase}' pvc web-pvc -n webserver)"
# Deployment
check "Deployment 'web-landing' existiert" obj_exists deploy web-landing -n webserver
check_eq "web-landing Replicas 3" "3" "$(ocjp '{.spec.replicas}' deploy web-landing -n webserver)"
J="$(oc get deploy web-landing -n webserver -o json 2>/dev/null)"
MOK="$(echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin); sp=d['spec']['template']['spec']
vols={v['name']:v.get('persistentVolumeClaim',{}).get('claimName') for v in sp.get('volumes',[])}
ok=False
for c in sp['containers']:
  for m in c.get('volumeMounts',[]):
    if m.get('mountPath')=='/usr/share/nginx/html' and vols.get(m.get('name'))=='web-pvc': ok=True
print('yes' if ok else 'no')" 2>/dev/null)"
check_eq "web-pvc gemountet unter /usr/share/nginx/html" "yes" "$MOK"
# Route HTTPS
check "Route in webserver vorhanden" bash -c "oc get route -n webserver 2>/dev/null | grep -q exoplanets-declarative-manifests"
RHOST="$(oc get route -n webserver -o jsonpath='{.items[*].spec.host}' 2>/dev/null)"
check_contains "Host exoplanets-declarative-manifests..." "exoplanets-declarative-manifests.apps.ocp4.example.com" "$RHOST"
TLS="$(oc get route -n webserver -o jsonpath='{.items[*].spec.tls.termination}' 2>/dev/null)"
if [[ -n "$TLS" ]]; then pass "Route ist TLS-gesichert ($TLS)"; else fail "Route ist nicht TLS-gesichert (HTTPS verlangt)"; fi
summary
