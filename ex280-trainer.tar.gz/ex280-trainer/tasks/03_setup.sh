#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 3 Setup — Project Permissions / Roles"
for p in team-alpha team-beta finance-apps it-automation; do ensure_project "$p"; done
info "Projekte team-alpha/team-beta/finance-apps/it-automation angelegt."
info "Ziele: alice=admin@team-beta, charlie=view@finance-apps, david=edit@it-automation."
