#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 23 Validate — Liveness Probe for cart"
J="$(oc get deploy cart -n amazon -o json 2>/dev/null)"
get(){ echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
c=d['spec']['template']['spec']['containers'][0]
lp=c.get('livenessProbe',{}) or {}
import json as j
print(j.dumps(lp))" 2>/dev/null; }
LP="$(get)"
echo "$LP" | grep -q 'tcpSocket' && pass "Liveness Probe ist tcpSocket" || fail "Liveness Probe ist tcpSocket"
PORT="$(echo "$LP" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('tcpSocket',{}).get('port',''))" 2>/dev/null)"
check_eq "Probe Port = 8080" "8080" "$PORT"
DELAY="$(echo "$LP" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('initialDelaySeconds',''))" 2>/dev/null)"
TO="$(echo "$LP" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d.get('timeoutSeconds',''))" 2>/dev/null)"
check_eq "initialDelaySeconds = 10" "10" "$DELAY"
check_eq "timeoutSeconds = 30" "30" "$TO"
summary
