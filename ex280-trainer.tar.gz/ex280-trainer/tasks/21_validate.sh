#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 21 Validate — Default Project Template with LimitRange"
# 1) cluster-Config zeigt auf ein projectRequestTemplate
TPL_NAME="$(ocjp '{.spec.projectRequestTemplate.name}' projects.config.openshift.io cluster)"
if [[ -n "$TPL_NAME" ]]; then pass "projects/cluster verweist auf Template '$TPL_NAME'"; else fail "projects/cluster hat KEIN projectRequestTemplate gesetzt"; fi
# 2) Template existiert in openshift-config und enthält LimitRange
if [[ -n "$TPL_NAME" ]] && oc get template "$TPL_NAME" -n openshift-config >/dev/null 2>&1; then
  pass "Template '$TPL_NAME' in openshift-config existiert"
  TJ="$(oc get template "$TPL_NAME" -n openshift-config -o json 2>/dev/null)"
  # Template-Objekte sauber parsen (grep auf JSON scheitert an '"kind": "LimitRange"' mit Space).
  LR_INFO="$(echo "$TJ" | python3 -c "import sys,json
try: d=json.load(sys.stdin)
except: print('no|no|no'); sys.exit()
has_lr=False; name_ok=False; vals=set()
for o in d.get('objects',[]):
    if o.get('kind')=='LimitRange':
        has_lr=True
        nm=o.get('metadata',{}).get('name','')
        if 'PROJECT_NAME' in nm and 'limits' in nm: name_ok=True
        for lim in o.get('spec',{}).get('limits',[]):
            for sect in ('default','defaultRequest','max','min'):
                v=lim.get(sect,{})
                if isinstance(v,dict):
                    for x in v.values(): vals.add(str(x))
print(('yes' if has_lr else 'no')+'|'+('yes' if name_ok else 'no')+'|'+(','.join(sorted(vals))))" 2>/dev/null)"
  LR_HAS="${LR_INFO%%|*}"
  REST="${LR_INFO#*|}"; LR_NAME="${REST%%|*}"; LR_VALS="${REST#*|}"
  check_eq "Template enthält ein LimitRange-Objekt" "yes" "$LR_HAS"
  check_eq "LimitRange-Name nutzt \${PROJECT_NAME}-limits" "yes" "$LR_NAME"
  check_contains "Memory-Werte (256Mi) vorhanden" "256Mi" "$LR_VALS"
  check_contains "Memory-Min (128Mi) vorhanden" "128Mi" "$LR_VALS"
else
  fail "Template in openshift-config nicht gefunden"
fi
info "Funktionstest optional: oc new-project tmptest && oc get limitrange -n tmptest"
summary
