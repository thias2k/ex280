#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 21 Validate — Default Project Template with LimitRange"
# 1) cluster-Config zeigt auf ein projectRequestTemplate
TPL_NAME="$(ocjp '{.spec.projectRequestTemplate.name}' projects.config.openshift.io cluster)"
if [[ -n "$TPL_NAME" ]]; then pass "projects/cluster verweist auf Template '$TPL_NAME'"; else fail "projects/cluster hat KEIN projectRequestTemplate gesetzt"; fi
# 2) Template existiert in openshift-config und enthält LimitRange
if [[ -n "$TPL_NAME" ]] && oc get template "$TPL_NAME" -n openshift-config >/dev/null 2>&1; then
  pass "Template '$TPL_NAME' in openshift-config existiert"
  TJ="$(oc get template "$TPL_NAME" -n openshift-config -o json 2>/dev/null)"
  if echo "$TJ" | grep -q '"kind":"LimitRange"'; then pass "Template enthält ein LimitRange-Objekt"; else fail "Template enthält KEIN LimitRange"; fi
  echo "$TJ" | grep -q '${PROJECT_NAME}-limits' && pass "LimitRange-Name nutzt \${PROJECT_NAME}-limits" || fail "LimitRange-Name nutzt \${PROJECT_NAME}-limits nicht"
  echo "$TJ" | grep -q '256Mi' && pass "Memory-Werte (256Mi) vorhanden" || fail "Memory-Werte (256Mi) fehlen"
  echo "$TJ" | grep -q '128Mi' && pass "Memory-Min (128Mi) vorhanden" || fail "Memory-Min (128Mi) fehlt"
else
  fail "Template in openshift-config nicht gefunden"
fi
info "Funktionstest optional: oc new-project tmptest && oc get limitrange -n tmptest"
summary
