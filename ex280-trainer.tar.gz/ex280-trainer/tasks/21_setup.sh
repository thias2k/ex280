#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 21 Setup — Default Project Template with LimitRange"
info "Ziel: bootstrap project template mit LimitRange '<PROJECT_NAME>-limits' erzeugen,"
info "      in openshift-config anlegen, und projects.config.openshift.io/cluster darauf zeigen lassen."
info "oc adm create-bootstrap-project-template -o yaml > template.yaml  (dann LimitRange einfügen)"
