#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 8 Setup — LimitRange in bluebook"
ensure_project bluebook
info "Ziel: LimitRange 'bluebook-limits'. Container: mem min 50Mi / max 250Mi / defaultRequest 100Mi."
info "Pod: cpu min 50m / max 250m; Container defaultRequest cpu 100m."
