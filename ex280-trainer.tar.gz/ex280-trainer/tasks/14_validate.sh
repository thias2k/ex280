#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 14 Validate — ConfigMap from file + mount"
check "ConfigMap 'web-cm' in publish existiert" obj_exists configmap web-cm -n publish
# Key index.html sollte existieren
KEYS="$(oc get configmap web-cm -n publish -o jsonpath='{.data}' 2>/dev/null)"
check_contains "ConfigMap enthält index.html" "index.html" "$KEYS"
# Mount /messages aus web-cm im Deployment web
J="$(oc get deploy web -n publish -o json 2>/dev/null)"
OK="$(echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
sp=d['spec']['template']['spec']
vols={v['name']:v.get('configMap',{}).get('name') for v in sp.get('volumes',[])}
ok=False
for c in sp['containers']:
  for m in c.get('volumeMounts',[]):
    if m.get('mountPath')=='/messages' and vols.get(m.get('name'))=='web-cm': ok=True
print('yes' if ok else 'no')" 2>/dev/null)"
check_eq "web-cm gemountet unter /messages" "yes" "$OK"
summary
