#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 16 Validate — Install File Integrity Operator"
NS="openshift-file-integrity"
check "Namespace '$NS' existiert" obj_exists ns "$NS"
SUB="$(oc get sub -n "$NS" -o json 2>/dev/null)"
if echo "$SUB" | grep -q 'file-integrity-operator'; then pass "Subscription file-integrity-operator vorhanden"; else fail "Subscription file-integrity-operator vorhanden"; fi
APPROVAL="$(oc get sub -n "$NS" -o jsonpath='{.items[?(@.spec.name=="file-integrity-operator")].spec.installPlanApproval}' 2>/dev/null)"
check_eq "Approval = Automatic" "Automatic" "$APPROVAL"
MON="$(ocjp '{.metadata.labels.openshift\.io/cluster-monitoring}' ns "$NS")"
check_eq "cluster-monitoring Label = true" "true" "$MON"
CSV_OK="$(oc get csv -n "$NS" -o jsonpath='{.items[?(@.status.phase=="Succeeded")].metadata.name}' 2>/dev/null | grep -c file-integrity)"
if [[ "${CSV_OK:-0}" -ge 1 ]]; then pass "Operator-CSV Succeeded"; else fail "Operator-CSV noch nicht Succeeded (ggf. warten)"; fi
summary
