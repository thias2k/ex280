#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 23 Setup — Liveness Probe for cart"
ensure_project amazon
oc -n amazon get deploy cart >/dev/null 2>&1 || \
  oc -n amazon create deployment cart --image=registry.access.redhat.com/ubi9/httpd-24 >/dev/null 2>&1
info "Deployment 'cart' in 'amazon' bereit (Container ohne Probe)."
info "Ziel: Liveness Probe TCP-Socket Port 8080, initialDelaySeconds=10, timeoutSeconds=30."
