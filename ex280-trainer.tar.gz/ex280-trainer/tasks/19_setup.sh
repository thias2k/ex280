#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 19 Setup — CronJob Creation"
ensure_project scheduler
oc -n scheduler get sa trigger-sa >/dev/null 2>&1 || oc -n scheduler create sa trigger-sa >/dev/null 2>&1
info "Projekt 'scheduler' + SA 'trigger-sa' bereit."
info "Ziel: CronJob 'job-runner', image bitnami/nginx:latest, schedule '5 4 2 * *',"
info "      successfulJobsHistoryLimit=14, serviceAccountName=trigger-sa."
