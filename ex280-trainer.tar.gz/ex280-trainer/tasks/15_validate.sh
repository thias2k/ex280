#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 15 Validate — Secure Route (edge TLS)"
check "Route 'marketing-route' existiert" obj_exists route marketing-route -n business
check_eq "TLS-Termination = edge" "edge" "$(ocjp '{.spec.tls.termination}' route marketing-route -n business)"
HOST="$(ocjp '{.spec.host}' route marketing-route -n business)"
check_eq "Host korrekt" "webapplication.apps.domain1.exampledomain.com" "$HOST"
CRT="$(ocjp '{.spec.tls.certificate}' route marketing-route -n business)"
KEY="$(ocjp '{.spec.tls.key}' route marketing-route -n business)"
if [[ -n "$CRT" ]]; then pass "Zertifikat in Route hinterlegt"; else fail "Zertifikat fehlt in Route"; fi
if [[ -n "$KEY" ]]; then pass "Private Key in Route hinterlegt"; else fail "Private Key fehlt in Route"; fi
summary
