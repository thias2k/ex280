#!/usr/bin/env bash
# Task 1 — Identity Provider HTPasswd :: VALIDATE
source "$(dirname "$0")/../lib/common.sh"
need_oc
hdr "Task 1 Validate — HTPasswd Identity Provider"

# OAuth CR enthält IdP vom Typ HTPasswd mit Namen ex280-htpasswd
IDP_JSON="$(oc get oauth cluster -o json 2>/dev/null)"
check_contains "OAuth enthält IdP-Namen 'ex280-htpasswd'" '"name":"ex280-htpasswd"' "$(echo "$IDP_JSON" | tr -d ' \n')"
check_contains "IdP-Typ ist HTPasswd" '"type":"HTPasswd"' "$(echo "$IDP_JSON" | tr -d ' \n')"

# Secret referenziert
SECRET_REF="$(ocjp '{.spec.identityProviders[?(@.name=="ex280-htpasswd")].htpasswd.fileData.name}' oauth cluster)"
check_eq "IdP referenziert Secret 'ex280-idp-secret'" "ex280-idp-secret" "$SECRET_REF"

# Secret existiert in openshift-config und hat key htpasswd
check "Secret 'ex280-idp-secret' in openshift-config existiert" obj_exists secret ex280-idp-secret -n openshift-config
HKEY="$(ocjp '{.data.htpasswd}' secret ex280-idp-secret -n openshift-config)"
if [[ -n "$HKEY" ]]; then pass "Secret hat Key 'htpasswd'"; else fail "Secret hat Key 'htpasswd'"; fi

# Alle 5 User im htpasswd-Blob vorhanden
if [[ -n "$HKEY" ]]; then
  DEC="$(echo "$HKEY" | base64 -d 2>/dev/null)"
  for u in alice bob charlie david emma; do
    if echo "$DEC" | grep -q "^${u}:"; then pass "User '$u' im htpasswd enthalten"; else fail "User '$u' im htpasswd enthalten"; fi
  done
fi

summary
