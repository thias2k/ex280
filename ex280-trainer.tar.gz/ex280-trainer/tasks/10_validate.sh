#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 10 Validate — Inject Secret into Application"
J="$(oc get deploy satellite -n moon -o json 2>/dev/null)"
OK="$(echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
found=False
for c in d['spec']['template']['spec']['containers']:
  for e in c.get('env',[]):
    if e.get('name')=='MOON_KEY':
      ref=e.get('valueFrom',{}).get('secretKeyRef',{})
      if ref.get('name')=='moon-secret' and ref.get('key')=='moon-key': found=True
  for ef in c.get('envFrom',[]):
    if ef.get('secretRef',{}).get('name')=='moon-secret': found=True
print('yes' if found else 'no')" 2>/dev/null)"
check_eq "ENV 'MOON_KEY' kommt aus Secret moon-secret/moon-key" "yes" "$OK"
summary
