#!/usr/bin/env bash
# Task 1 — Identity Provider HTPasswd :: SETUP
# Bereitet nur vor (Projekte/User existieren ggf. noch nicht). Lösung machst du selbst.
source "$(dirname "$0")/../lib/common.sh"
need_oc
hdr "Task 1 Setup — HTPasswd Identity Provider"
info "Ziel: IdP 'ex280-htpasswd', Secret 'ex280-idp-secret' in openshift-config."
info "User: alice/alice@123 bob/bob123 charlie/charlie@123 david/david@123 emma/emma123"
info "Keine Vorbereitung nötig — du baust IdP, Secret und htpasswd-File selbst."
info "Tipp: htpasswd -cBb htpasswd alice alice@123 ; dann oc create secret generic ... --from-file=htpasswd"
