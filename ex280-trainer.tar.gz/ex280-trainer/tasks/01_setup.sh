#!/usr/bin/env bash
# Task 1 — Identity Provider HTPasswd :: SETUP
# Bereitet nur vor. Lösung (IdP, Secret, htpasswd-File, User) machst du selbst.
source "$(dirname "$0")/../lib/common.sh"
need_oc
hdr "Task 1 Setup — HTPasswd Identity Provider"
info "Ziel: HTPasswd-IdP 'ex280-htpasswd', Credentials im Secret 'ex280-idp-secret' (openshift-config)."
echo
info "Lege diese 5 User im htpasswd-File an (exakte Passwörter aus der Taskliste):"
printf '       %-10s %s\n' "alice"   "alice@123"
printf '       %-10s %s\n' "bob"     "bob123"
printf '       %-10s %s\n' "charlie" "charlie@123"
printf '       %-10s %s\n' "david"   "david@123"
printf '       %-10s %s\n' "emma"    "emma123"
echo
printf '  %s!%s %sDiese 5 User brauchst du in den Folgetasks wieder:%s\n' "$YEL" "$RST" "$BLD" "$RST"
info "   Task 2 (RBAC: cluster-admin/cluster-reader/self-provisioner),"
info "   Task 3 (Projekt-Rollen admin/view/edit), Task 4 (Gruppen manager/project-admin)."
info "   -> Lege ALLE 5 an, nicht nur die, die in Task 1 sichtbar geprüft werden."
echo
info "Ablauf-Skizze (Werte per Copy&Paste, um Tippfehler zu vermeiden):"
info "   htpasswd -cBb htpasswd alice alice@123"
info "   htpasswd -Bb  htpasswd bob bob123"
info "   ... (charlie, david, emma analog) ..."
info "   oc create secret generic ex280-idp-secret --from-file=htpasswd=htpasswd -n openshift-config"
info "   danach OAuth/cluster um den HTPasswd-IdP 'ex280-htpasswd' ergänzen, der dieses Secret referenziert."
echo
info "Validierung prüft: IdP-Name & -Typ, Secret-Referenz, und ob alle 5 User im htpasswd enthalten sind."
