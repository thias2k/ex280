#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 7 Setup — Horizontal Pod Autoscaler"
ensure_project solar
oc -n solar get deploy titan >/dev/null 2>&1 || \
  oc -n solar create deployment titan --image="$(httpd_image)" >/dev/null 2>&1
info "Deployment 'titan' im Projekt 'solar'. Ziele: requests.cpu=50m, limits.cpu=250m,"
info "HPA min=2 max=5 cpu-percent=75."
