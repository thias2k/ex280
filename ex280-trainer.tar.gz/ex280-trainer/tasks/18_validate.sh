#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 18 Validate — Collect & Upload Cluster Support Data"
CID="$(oc get clusterversion -o jsonpath='{.items[0].spec.clusterID}' 2>/dev/null)"
info "ClusterID: ${CID:-<unbekannt>}"
TAR="$(ls -1 "$HOME"/ex280-ocp-*.tar.gz 2>/dev/null | head -1)"
if [[ -n "$TAR" ]]; then
  pass "Tar-Archiv gefunden: $(basename "$TAR")"
  if tar -tzf "$TAR" >/dev/null 2>&1; then pass "Archiv ist gültiges t.gz"; else fail "Archiv ist kein gültiges t.gz"; fi
  if [[ -n "$CID" && "$TAR" == *"$CID"* ]]; then pass "Dateiname enthält ClusterID"; else fail "Dateiname enthält ClusterID nicht"; fi
else
  fail "Kein ex280-ocp-<clusterID>.tar.gz im HOME gefunden"
fi
info "Upload selbst ist nicht automatisch prüfbar — führe ./upload-cluster-data aus."
summary
