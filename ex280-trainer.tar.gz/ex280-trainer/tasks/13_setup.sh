#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 13 Setup — Fix broken MySQL deployment"
ensure_project database
# absichtlich kaputt: ohne ENV crasht mysql
oc -n database delete deploy mysql >/dev/null 2>&1
oc -n database create deployment mysql --image=registry.redhat.io/rhel9/mysql-80 >/dev/null 2>&1 || \
  oc -n database create deployment mysql --image=quay.io/centos7/mysql-80-centos7 >/dev/null 2>&1
info "Kaputtes 'mysql' Deployment in 'database' (CrashLoop, ENV fehlen). Ziel: reparieren, NICHT neu anlegen."
info "Setze MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE, MYSQL_ROOT_PASSWORD."
