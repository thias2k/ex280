#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 13 Setup — Fix broken MySQL deployment"
ensure_project database
# absichtlich kaputt: ohne MYSQL_* ENV crasht der DB-Container (CrashLoopBackOff)
oc -n database delete deploy mysql >/dev/null 2>&1

# Internes Classroom-Image ist im ROL-Lab erreichbar (kein externes Pull-Secret noetig).
# Reihenfolge: internes Image -> registry.redhat.io -> quay (Fallback fuer andere Umgebungen).
IMG=""
for cand in \
  "registry.ocp4.example.com:8443/rhel9/mysql-80:1" \
  "registry.ocp4.example.com:8443/rhel8/mysql-80:1" \
  "registry.redhat.io/rhel9/mysql-80:1" \
  "quay.io/centos7/mysql-80-centos7"; do
  if oc image info "$cand" >/dev/null 2>&1; then IMG="$cand"; break; fi
done
# Falls 'oc image info' nichts bestaetigt (z.B. eingeschraenkter Zugriff), nimm das interne Image als Default.
[[ -z "$IMG" ]] && IMG="registry.ocp4.example.com:8443/rhel9/mysql-80:1"

oc -n database create deployment mysql --image="$IMG" >/dev/null 2>&1
info "Kaputtes 'mysql' Deployment in 'database' angelegt (Image: $IMG)."
info "Erwarteter Zustand: Pod startet NICHT (fehlende MYSQL_* ENV). Ziel: reparieren, NICHT neu anlegen."
info "Setze MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE, MYSQL_ROOT_PASSWORD."
echo
info "Falls der Pod ImagePullBackOff zeigt: Image im Lab nicht ziehbar -> mit erreichbarem Image neu anlegen, z.B."
info "  oc set image deployment/mysql mysql=registry.ocp4.example.com:8443/rhel9/mysql-80:1 -n database"
