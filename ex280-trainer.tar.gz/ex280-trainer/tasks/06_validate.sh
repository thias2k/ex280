#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 6 Validate — Manually Scale Deployment"
check_eq "Deployment 'jet' Spec-Replicas = 5" "5" "$(ocjp '{.spec.replicas}' deploy jet -n apollo)"
RDY="$(ocjp '{.status.readyReplicas}' deploy jet -n apollo)"; RDY="${RDY:-0}"
check_eq "5 Replicas ready" "5" "$RDY"
summary
