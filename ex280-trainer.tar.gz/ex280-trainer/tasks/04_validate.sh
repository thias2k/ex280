#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 4 Validate — Groups and Group Permissions"
check "Gruppe 'manager' existiert" obj_exists group manager
check "Gruppe 'project-admin' existiert" obj_exists group project-admin
MAN="$(ocjp '{.users[*]}' group manager)"; PA="$(ocjp '{.users[*]}' group project-admin)"
check_contains "alice in 'manager'" "alice" "$MAN"
check_contains "charlie in 'project-admin'" "charlie" "$PA"
check_contains "david in 'project-admin'" "david" "$PA"
# group-RBAC sauber prüfen: pro RoleBinding muss roleRef UND subject(Group) zusammenpassen.
# (grep auf rohem JSON kann Rolle und Subjekt nicht korrekt zuordnen -> daher Python.)
RB="$(oc get rolebinding -n team-alpha -o json 2>/dev/null)"
rb_binds() { # rb_binds <role> <group>
  echo "$RB" | python3 -c "import sys,json
role='$1'; grp='$2'
try: d=json.load(sys.stdin)
except: print('no'); sys.exit()
for rb in d.get('items',[]):
    rr=rb.get('roleRef',{})
    if rr.get('name')!=role: continue
    for s in rb.get('subjects') or []:
        if s.get('kind')=='Group' and s.get('name')==grp:
            print('yes'); sys.exit()
print('no')" 2>/dev/null
}
check_eq "manager hat edit in team-alpha" "yes" "$(rb_binds edit manager)"
check_eq "project-admin hat view in team-alpha" "yes" "$(rb_binds view project-admin)"
summary
