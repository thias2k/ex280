#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 4 Validate — Groups and Group Permissions"
check "Gruppe 'manager' existiert" obj_exists group manager
check "Gruppe 'project-admin' existiert" obj_exists group project-admin
MAN="$(ocjp '{.users[*]}' group manager)"; PA="$(ocjp '{.users[*]}' group project-admin)"
check_contains "alice in 'manager'" "alice" "$MAN"
check_contains "charlie in 'project-admin'" "charlie" "$PA"
check_contains "david in 'project-admin'" "david" "$PA"
# group-RBAC über RoleBindings prüfen
RB="$(oc get rolebinding -n team-alpha -o json 2>/dev/null)"
if echo "$RB" | grep -q '"name":"manager"' && echo "$RB" | grep -q '"name":"edit"'; then pass "manager hat edit in team-alpha"; else fail "manager hat edit in team-alpha"; fi
if echo "$RB" | grep -q '"name":"project-admin"' && echo "$RB" | grep -q '"name":"view"'; then pass "project-admin hat view in team-alpha"; else fail "project-admin hat view in team-alpha"; fi
summary
