#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 13 Validate — Fix broken MySQL deployment"
J="$(oc get deploy mysql -n database -o json 2>/dev/null)"
has_env(){ echo "$J" | python3 -c "import sys,json
d=json.load(sys.stdin)
names=set()
for c in d['spec']['template']['spec']['containers']:
  for e in c.get('env',[]): names.add(e.get('name'))
  for ef in c.get('envFrom',[]): names.add('__envFrom__')
print('yes' if '$1' in names or '__envFrom__' in names else 'no')" 2>/dev/null; }
for v in MYSQL_USER MYSQL_PASSWORD MYSQL_DATABASE MYSQL_ROOT_PASSWORD; do
  check_eq "ENV $v gesetzt" "yes" "$(has_env $v)"
done
AVAIL="$(ocjp '{.status.availableReplicas}' deploy mysql -n database)"; AVAIL="${AVAIL:-0}"
if [[ "$AVAIL" -ge 1 ]]; then pass "mysql-Pod läuft (Available>=1)"; else fail "mysql-Pod läuft noch nicht (CrashLoop?)"; fi
summary
