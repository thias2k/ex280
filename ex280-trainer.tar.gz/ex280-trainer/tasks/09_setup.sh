#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 9 Setup — Secret Creation"
ensure_project moon
info "Ziel: Secret 'moon-secret' in 'moon' mit Key 'moon-key' = Wert (base64: bW9vbi1wYXNzd29yZAo=)."
info "Klartext des Werts ist 'moon-password'. oc create secret generic moon-secret --from-literal=moon-key=moon-password"
