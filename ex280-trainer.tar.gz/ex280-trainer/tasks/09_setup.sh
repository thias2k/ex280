#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 9 Setup — Secret Creation"
ensure_project moon
info "Ziel: Secret 'moon-secret' in 'moon', Key 'moon-key', data-Wert exakt: bW9vbi1wYXNzd29yZAo="
info "Dieser base64-Wert dekodiert zu 'moon-password' (mit abschliessendem Zeilenumbruch)."
echo
printf '  %s!%s %sWichtig:%s data-Felder sind IMMER base64. Der angegebene String IST der data-Wert.\n' "$YEL" "$RST" "$BLD" "$RST"
info "Haeufiger Fehler: --from-literal=moon-key=bW9vbi1wYXNzd29yZAo= -> oc kodiert NOCHMAL (doppelt, falsch)."
echo
info "Sauberer Weg (exakter Hash inkl. Zeilenumbruch):"
info "   printf 'moon-password\\n' > /tmp/mk"
info "   oc create secret generic moon-secret --from-file=moon-key=/tmp/mk -n moon"
info "Alternative: data-Wert direkt in die YAML schreiben (dry-run -> data.moon-key ersetzen -> oc apply)."
