#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 9 Validate — Secret Creation"
check "Secret 'moon-secret' in moon existiert" obj_exists secret moon-secret -n moon
V="$(ocjp '{.data.moon-key}' secret moon-secret -n moon)"
EXP="bW9vbi1wYXNzd29yZAo="   # exakt wie in der Aufgabe; dekodiert zu 'moon-password\n'
if [[ "$V" == "$EXP" ]]; then
  pass "Key 'moon-key' hat exakt den geforderten base64-Wert"
else
  fail "Key 'moon-key' Wert stimmt nicht"
  # gezielte Diagnose, damit der typische Doppel-Encoding-Fehler sofort klar wird
  DEC="$(echo "$V" | base64 -d 2>/dev/null)"
  if [[ "$DEC" == "$EXP" ]]; then
    info "  Ursache: base64-String wurde via --from-literal nochmal kodiert (doppelt)."
    info "  Loesung A: Klartext nutzen (oc kodiert dann selbst)."
    info "  Loesung B: Wert direkt ins data-Feld schreiben (per YAML/oc apply)."
    info "  Der geforderte data.moon-key ist exakt: $EXP"
  elif [[ "$DEC" == "moon-password" ]]; then
    info "  Fast richtig: Klartext 'moon-password' OHNE Zeilenumbruch ergibt einen anderen Hash."
    info "  Der Aufgaben-Wert dekodiert zu 'moon-password' MIT abschliessendem Zeilenumbruch."
    info "  Tipp: printf 'moon-password\\n' in eine Datei, dann --from-file=moon-key=<datei>."
  else
    info "  Ist (base64):  '$V'   ->  dekodiert: '$DEC'"
    info "  Soll (base64): '$EXP'  ->  dekodiert: 'moon-password' (+ Zeilenumbruch)"
  fi
fi
summary
