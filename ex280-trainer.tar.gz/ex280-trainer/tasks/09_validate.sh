#!/usr/bin/env bash
source "$(dirname "$0")/../lib/common.sh"; need_oc
hdr "Task 9 Validate — Secret Creation"
check "Secret 'moon-secret' in moon existiert" obj_exists secret moon-secret -n moon
V="$(ocjp '{.data.moon-key}' secret moon-secret -n moon)"
# Aufgabenstellung nennt base64 bW9vbi1wYXNzd29yZAo= -> Klartext 'moon-password\n'
DEC="$(echo "$V" | base64 -d 2>/dev/null)"
if [[ "$V" == "bW9vbi1wYXNzd29yZAo=" || "$DEC" == "moon-password" ]]; then
  pass "Key 'moon-key' hat korrekten Wert"
else
  fail "Key 'moon-key' Wert stimmt nicht (ist base64: '$V')"
fi
summary
