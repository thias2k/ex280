#!/usr/bin/env bash
# Task 2 — Cluster Access Control / RBAC :: SETUP
source "$(dirname "$0")/../lib/common.sh"
need_oc
hdr "Task 2 Setup — RBAC Users"
info "Voraussetzung: Task 1 abgeschlossen (User existieren via IdP-Login)."
info "Ziele: emma=cluster-admin, alice darf Projekte anlegen, charlie != cluster-admin,"
info "       david darf KEINE Projekte anlegen, bob=cluster-reader, kubeadmin entfernt."
info "Hinweis: User erscheinen erst als Identity nach erstem Login. Für RBAC reicht oc adm policy."
